// ============================================================
// Cedarwings SAS — Supabase Configuration
// Replace the values below with your actual Supabase project details
// Found in: Supabase Dashboard → Project Settings → API
// ============================================================

export const SUPABASE_CONFIG = {
  url: 'https://YOUR_PROJECT_ID.supabase.co',       // ← replace
  anonKey: 'YOUR_ANON_KEY_HERE'                      // ← replace
}
