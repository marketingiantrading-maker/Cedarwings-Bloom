# Cedarwings SAS — Manufacturing Operations Platform

A full-stack manufacturing dashboard for dental aligner production. Built with vanilla HTML/CSS/JS + Supabase.

## Pages

| File | Description |
|---|---|
| `index.html` | Login — Employee (name) or Manager (PIN) |
| `manager.html` | Manager dashboard — KPIs, active sessions, charts, alerts |
| `production.html` | Production tracking — record aligners/cases, auto-deducts inventory |
| `machines.html` | Machine status — running/idle/maintenance, live timers, utilisation |
| `clocking.html` | Employee clocking terminal — workflow-enforced steps |
| `inventory.html` | Inventory management — FEFO, requisitions, reorder settings |

## Setup

### 1. Supabase Tables

Run both SQL files in your Supabase SQL Editor in this order:
1. `supabase_inventory_automation_upgrade_fixed.sql` (existing tables)
2. `new_tables.sql` (new tables: employees, machines, production_params, production_records)

### 2. Configure Supabase credentials

Edit `config.js` with your project URL and anon key:
```js
export const SUPABASE_CONFIG = {
  url: 'https://YOUR_PROJECT_ID.supabase.co',
  anonKey: 'YOUR_ANON_KEY_HERE'
}
```

Found in: Supabase Dashboard → Project Settings → API

### 3. Serve locally

Since pages use ES modules (`import`), you need a local server:

```bash
# Python
python3 -m http.server 8080

# Node (npx)
npx serve .

# VS Code: use Live Server extension
```

Then open `http://localhost:8080`

### 4. Default credentials

- **Manager PIN**: `1234` (changeable in Settings)
- **Employees**: Enter any name on login

## Workflow (enforced in clocking terminal)

Printing → Cleaning → Thermoforming → Line Cut → Laser Marking → Packaging

## Auto-requisition logic

When a production batch is submitted:
1. Calculates material consumption based on `production_params` table
2. Deducts from inventory lots using FEFO (First Expired, First Out)
3. Logs to `inventory_stock_history` and `inventory_batch_consumption`
4. Runs `generate_auto_requisitions()` — creates pending requisitions for items below minimum

## Tech Stack

- **Frontend**: Vanilla HTML/CSS/JS (no build step)
- **Database**: Supabase (PostgreSQL)
- **Auth**: Simple PIN-based role switching (localStorage)
- **Charts**: Chart.js
- **Font**: DM Sans + JetBrains Mono
